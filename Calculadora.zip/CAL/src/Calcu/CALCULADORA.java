package Calcu;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CALCULADORA {

	private JFrame frmCalculadora;
	JLabel lblSuma, lblResta, lblMulti, lblDivi, lblModulo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CALCULADORA window = new CALCULADORA();
					window.frmCalculadora.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CALCULADORA() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmCalculadora = new JFrame();
		frmCalculadora.setTitle("CALCULADORA");
		frmCalculadora.setBounds(100, 100, 450, 323);
		frmCalculadora.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmCalculadora.getContentPane().setLayout(null);
		
		JButton btnSuma = new JButton("Suma");
		btnSuma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int a = Integer.parseInt(JOptionPane.showInputDialog("Introduce numero 1"));
					int b = Integer.parseInt(JOptionPane.showInputDialog("Introduce numero 2"));
					lblSuma.setText("La suma es:"+(a+b));
				}catch(Exception ex) {
					JOptionPane.showMessageDialog(null, "error");
					
				}
				
				
				
			}
		});
		btnSuma.setBounds(20, 11, 89, 23);
		frmCalculadora.getContentPane().add(btnSuma);
		
		lblSuma = new JLabel("");
		lblSuma.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblSuma.setBounds(129, 15, 131, 14);
		frmCalculadora.getContentPane().add(lblSuma);
		
		JButton btnResta = new JButton("Resta");
		btnResta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int a = Integer.parseInt(JOptionPane.showInputDialog("Introduce numero 1"));
					int b = Integer.parseInt(JOptionPane.showInputDialog("Introduce numero 2"));
					lblResta.setText("La resta es:" +(a-b));
				}catch(Exception ex) {
					JOptionPane.showMessageDialog(null, "error");
					
				}
			}
		});
		btnResta.setBounds(20, 57, 89, 23);
		frmCalculadora.getContentPane().add(btnResta);
		
		lblResta = new JLabel("");
		lblResta.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblResta.setBounds(129, 61, 131, 14);
		frmCalculadora.getContentPane().add(lblResta);
		
		JButton btnMulti = new JButton("Multiplicación");
		btnMulti.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int a = Integer.parseInt(JOptionPane.showInputDialog("Introduce numero 1"));
					int b = Integer.parseInt(JOptionPane.showInputDialog("Introduce numero 2"));
					lblMulti.setText("La Multiplicación es:"+(a*b));
				}catch(Exception ex) {
					JOptionPane.showMessageDialog(null, "error");
					
				}
			}
		});
		btnMulti.setBounds(20, 97, 99, 23);
		frmCalculadora.getContentPane().add(btnMulti);
		
		lblMulti = new JLabel("");
		lblMulti.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblMulti.setBounds(129, 101, 157, 14);
		frmCalculadora.getContentPane().add(lblMulti);
		
		JButton btnDivi = new JButton("Division");
		btnDivi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int a = Integer.parseInt(JOptionPane.showInputDialog("Introduce numero 1"));
					int b = Integer.parseInt(JOptionPane.showInputDialog("Introduce numero 2"));
					lblDivi.setText("La división entera es:"+(a/b));
				}catch(Exception ex) {
					JOptionPane.showMessageDialog(null, "error");
					
				}
			}
		});
		btnDivi.setBounds(20, 143, 89, 23);
		frmCalculadora.getContentPane().add(btnDivi);
		
		lblDivi = new JLabel("");
		lblDivi.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblDivi.setBounds(129, 147, 131, 14);
		frmCalculadora.getContentPane().add(lblDivi);
		
		JButton btnModulo = new JButton("Modulo");
		btnModulo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int a = Integer.parseInt(JOptionPane.showInputDialog("Introduce numero 1"));
					int b = Integer.parseInt(JOptionPane.showInputDialog("Introduce numero 2"));
					lblModulo.setText("El modulo es:"+(a%b));
				}catch(Exception ex) {
					JOptionPane.showMessageDialog(null, "error");
					
				}
			}
		});
		btnModulo.setBounds(20, 192, 89, 23);
		frmCalculadora.getContentPane().add(btnModulo);
		
		lblModulo = new JLabel("");
		lblModulo.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblModulo.setBounds(129, 196, 131, 14);
		frmCalculadora.getContentPane().add(lblModulo);
		
		JButton btnBorrar = new JButton("Borrar");
		btnBorrar.setBounds(294, 250, 89, 23);
		frmCalculadora.getContentPane().add(btnBorrar);
	}
}
